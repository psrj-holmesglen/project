-- MySQL dump 10.13  Distrib 5.5.36, for Linux (x86_64)
--
-- Host: localhost    Database: dstcapp
-- ------------------------------------------------------
-- Server version	5.5.36-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `dstcapp`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `dstcapp` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `dstcapp`;

--
-- Table structure for table `business_rules`
--

DROP TABLE IF EXISTS `business_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_rules` (
  `Bus_Rule` char(30) NOT NULL,
  `Value` char(30) NOT NULL,
  PRIMARY KEY (`Bus_Rule`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_rules`
--

LOCK TABLES `business_rules` WRITE;
/*!40000 ALTER TABLE `business_rules` DISABLE KEYS */;
INSERT INTO `business_rules` VALUES ('And dont blink','yes'),('Blink and your dead','yes'),('Dont Blink','yes'),('Dont look away','yes'),('Dont turn your back','yes');
/*!40000 ALTER TABLE `business_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conference`
--

DROP TABLE IF EXISTS `conference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conference` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Title` varchar(100) NOT NULL,
  `Description` varchar(400) NOT NULL,
  `Start_Time` datetime NOT NULL,
  `End_Time` datetime NOT NULL,
  `Organiser` varchar(30) NOT NULL,
  `Location` varchar(80) NOT NULL,
  `Contact` char(25) NOT NULL,
  `Last_Updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Download_Avail` tinyint(1) NOT NULL DEFAULT '1',
  `FilePath` varchar(100) DEFAULT NULL,
  `Feedback` smallint(5) unsigned DEFAULT NULL,
  `Venue` smallint(5) unsigned NOT NULL,
  `Token` int(11) NOT NULL,
  `Conference_Admin_Id` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Token` (`Token`),
  KEY `Conference_Feedback_fk` (`Feedback`),
  KEY `Conference_Venue_fk` (`Venue`),
  KEY `Token_2` (`Token`),
  CONSTRAINT `Conference_Feedback_fk` FOREIGN KEY (`Feedback`) REFERENCES `feedback` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Conference_Venue_fk` FOREIGN KEY (`Venue`) REFERENCES `venue` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conference`
--

LOCK TABLES `conference` WRITE;
/*!40000 ALTER TABLE `conference` DISABLE KEYS */;
INSERT INTO `conference` VALUES (77,'DSTC Melbourne 2014','Definitive Surgical Trauma Care, Melbourne 2014','2014-11-09 09:30:00','2014-11-10 16:30:00','DSTC','Epworth HealthCare, 89 Bridge Rd, Richmond, 3121','Geoffrey Rose','2014-11-06 23:27:49',1,'No File Uploaded',3,1,1277,1);
/*!40000 ALTER TABLE `conference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conference_fb_section`
--

DROP TABLE IF EXISTS `conference_fb_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conference_fb_section` (
  `Conference` smallint(5) unsigned NOT NULL,
  `Feedback_Section` smallint(5) unsigned NOT NULL,
  KEY `Conference_FB_Feedback_Section_fk` (`Feedback_Section`),
  KEY `Conference_FB_Section_Conference_fk` (`Conference`),
  CONSTRAINT `Conference_FB_Feedback_Section_fk` FOREIGN KEY (`Feedback_Section`) REFERENCES `feedback_section` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Conference_FB_Section_Conference_fk` FOREIGN KEY (`Conference`) REFERENCES `conference` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conference_fb_section`
--

LOCK TABLES `conference_fb_section` WRITE;
/*!40000 ALTER TABLE `conference_fb_section` DISABLE KEYS */;
/*!40000 ALTER TABLE `conference_fb_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conference_section`
--

DROP TABLE IF EXISTS `conference_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conference_section` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Section_Title` varchar(100) NOT NULL,
  `Last_Updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Ordering` int(6) DEFAULT NULL,
  `Conference` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Conference_Section_Conference_fk` (`Conference`),
  CONSTRAINT `Conference_Section_Conference_fk` FOREIGN KEY (`Conference`) REFERENCES `conference` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conference_section`
--

LOCK TABLES `conference_section` WRITE;
/*!40000 ALTER TABLE `conference_section` DISABLE KEYS */;
INSERT INTO `conference_section` VALUES (25,'Surgical Decision Making - Days 1&2','2014-11-07 00:45:53',1,77),(26,'Surgical Techniques and Approaches - Days 1&2','2014-11-07 00:45:59',2,77),(27,'Laboratory Sessions','2014-11-07 00:45:46',3,77),(28,'Interactive Sessions','2014-11-07 00:45:41',4,77);
/*!40000 ALTER TABLE `conference_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conference_sponsor`
--

DROP TABLE IF EXISTS `conference_sponsor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conference_sponsor` (
  `Conference` smallint(5) unsigned NOT NULL,
  `Sponsor` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`Conference`,`Sponsor`),
  KEY `Conference_Sponsor_Sponsor_fk` (`Sponsor`),
  CONSTRAINT `Conference_Sponsor_Conference_fk` FOREIGN KEY (`Conference`) REFERENCES `conference` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Conference_Sponsor_Sponsor_fk` FOREIGN KEY (`Sponsor`) REFERENCES `sponsor` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conference_sponsor`
--

LOCK TABLES `conference_sponsor` WRITE;
/*!40000 ALTER TABLE `conference_sponsor` DISABLE KEYS */;
INSERT INTO `conference_sponsor` VALUES (77,1);
/*!40000 ALTER TABLE `conference_sponsor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipment` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Equipment_Name` varchar(30) NOT NULL,
  `Equipment_Type` varchar(60) NOT NULL,
  `Supplier_Webite` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment`
--

LOCK TABLES `equipment` WRITE;
/*!40000 ALTER TABLE `equipment` DISABLE KEYS */;
INSERT INTO `equipment` VALUES (1,'CT Scanner','Scanner',''),(2,'PET','Functional imaging technique',''),(3,'MRI','Magnetic resonance imaging','www.magnetec.com'),(4,'Ultrasound','Imaging technique','');
/*!40000 ALTER TABLE `equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Feedback_Title` varchar(50) NOT NULL,
  `Feedback_Desc` varchar(250) DEFAULT NULL,
  `Last_Updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES (3,'Feedback for DSTC','Melbourne 2014 Course Feedback','2014-11-07 03:00:09'),(4,'Feedback for Conference 10','This is for testing purposes','2014-02-24 06:10:10'),(5,'Testing Feedback Edit','This is for testing purposes','2014-09-21 10:53:59'),(6,'new feedback testing1','feedback description1','2014-09-20 14:33:02'),(9,'del feed title','del feed description','2014-09-20 15:03:26'),(10,'Demography Conf Feedback Form','Demography conference feedback form','2014-10-09 19:57:14'),(11,'Demography Session Feedback Form','Demography session feedback form','2014-10-09 19:57:29'),(12,'pptest','ppdescription','2014-10-25 00:51:25'),(13,'pptest','ppdescription','2014-10-25 00:51:58'),(14,'hgoe','oghaeriogaeorgrgirhe','2014-10-28 09:59:17');
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback_option`
--

DROP TABLE IF EXISTS `feedback_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback_option` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Option_Number` varchar(5) DEFAULT NULL,
  `Option_Text` varchar(100) DEFAULT NULL,
  `Feedback_Question` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Feedback_Option_Feedback_Question_fk` (`Feedback_Question`),
  CONSTRAINT `Feedback_Option_Feedback_Question_fk` FOREIGN KEY (`Feedback_Question`) REFERENCES `feedback_question` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback_option`
--

LOCK TABLES `feedback_option` WRITE;
/*!40000 ALTER TABLE `feedback_option` DISABLE KEYS */;
INSERT INTO `feedback_option` VALUES (115,'0115','No benefit',29),(116,'0116','Some Benefit',29),(117,'0117','Quite helpful',29),(118,'0118','Very beneficial',29),(119,'0001','Not confident in any case',31),(120,'0002','Confident only in some cases',31),(121,'0003','Confident in most cases',31),(122,'0004','Confident with every major trauma situation',31),(123,'0005','Uncomfortable with all areas of major trauma',32),(124,'0006','Confident & competent only in some areas of major trauma',32),(125,'0007','Confident & competent in most areas of major trauma',32),(126,'0008','Confident & competent with any major trauma situation',32),(127,'0009','No benefit',33),(128,'0010','Some Benefit',33),(129,'0011','Quite helpful',33),(130,'0012','Very beneficial',33),(131,'0013','Indispensable',33),(132,'0014','Not at all',34),(133,'0015','To a low degree',34),(134,'0016','To a moderate degree',34),(135,'0017','To a high degree',34),(136,'0018','To a very high degree',34),(137,'0019','Inappropriately low',35),(138,'0020','About right',35),(139,'0021','Inappropriately high',35),(140,'0022','No benefit',36),(141,'0023','Some Benefit',36),(142,'0024','Quite helpful',36),(143,'0025','Very beneficial',36),(144,'0026','Indispensable',36),(145,'0027','No benefit',37),(146,'0028','Some Benefit',37),(147,'0029','Quite helpful',37),(148,'0030','Very beneficial',37),(149,'0031','Indispensable',37),(150,'0032','No benefit',38),(151,'0033','Some Benefit',38),(152,'0034','Quite helpful',38),(153,'0035','Very beneficial',38),(154,'0036','Indispensable',38),(155,'0037','No benefit',39),(156,'0038','Some Benefit',39),(157,'0039','Quite helpful',39),(158,'0040','Very beneficial',39),(159,'0041','Indispensable',39);
/*!40000 ALTER TABLE `feedback_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback_question`
--

DROP TABLE IF EXISTS `feedback_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback_question` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Question_Number` varchar(5) NOT NULL,
  `Question_Text` varchar(200) NOT NULL,
  `Type` smallint(4) NOT NULL,
  `Question_Type` char(10) DEFAULT NULL,
  `Feedback_Section` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Feedback_Question_Feedback_Section_fk` (`Feedback_Section`),
  KEY `Feedback_Question_Question_Type_fk` (`Question_Type`),
  CONSTRAINT `Feedback_Question_Feedback_Section_fk` FOREIGN KEY (`Feedback_Section`) REFERENCES `feedback_section` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Feedback_Question_Question_Type_fk` FOREIGN KEY (`Question_Type`) REFERENCES `question_type` (`Question_Type`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback_question`
--

LOCK TABLES `feedback_question` WRITE;
/*!40000 ALTER TABLE `feedback_question` DISABLE KEYS */;
INSERT INTO `feedback_question` VALUES (29,'Q029','Regarding course, how to look after patients who has serious trauma after seeing them:',2,'Multi',9),(30,'Q030','Regarding course content, what is your background to make Surgical Descision:',1,'Multi',9),(31,'0001','Confidence level dealing with major trauma prior to the DSTC',1,'Multi',10),(32,'0002','Confidence level after having completed the dstc',1,'Multi',10),(33,'0003','Regarding your overall experience of the course, the DSTC was of:',1,'Multi',10),(34,'Q004','Regarding course objectives, to what degree were they clear & appropriate:',1,'Multi',10),(35,'Q005','Regarding course workload it was:',1,'Multi',10),(36,'Q006','Regarding course content, how do you rate the importance of Surgical Descision Making:',1,'Multi',10),(37,'Q007','Regarding course content, how do you rate the importance of Surgical Technique Theory:',1,'Multi',10),(38,'Q008','How valuable was the Manual?',1,'Multi',10),(39,'Q009','How valuable was the DVD Material?',1,'Multi',10),(56,'','this is for session feedback question trial 56',2,NULL,9),(57,'','question text question text question text ',2,NULL,11),(58,'','pptest',2,NULL,11),(60,'','test test',2,NULL,12),(61,'','something',2,NULL,11),(62,'','retest',2,NULL,11),(63,'','Test question for session feedback conference 71',2,NULL,13);
/*!40000 ALTER TABLE `feedback_question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback_section`
--

DROP TABLE IF EXISTS `feedback_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback_section` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Section_Start` datetime DEFAULT NULL,
  `Section_End` datetime DEFAULT NULL,
  `Section_Title` varchar(50) NOT NULL,
  `Section_Desc` varchar(250) DEFAULT NULL,
  `Type` enum('Conference','Session','Demographic') NOT NULL,
  `Last_Updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Feedback` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Feedback_Section_Feedback_fk` (`Feedback`),
  CONSTRAINT `Feedback_Section_Feedback_fk` FOREIGN KEY (`Feedback`) REFERENCES `feedback` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback_section`
--

LOCK TABLES `feedback_section` WRITE;
/*!40000 ALTER TABLE `feedback_section` DISABLE KEYS */;
INSERT INTO `feedback_section` VALUES (9,'2014-12-25 14:50:00','2014-12-25 15:50:00','Section TYPE-III','Statistical Research method','Session','2014-02-24 06:10:10',4),(10,'2014-12-25 12:50:00','2014-12-25 13:50:00','Section A','Confidence levels & Overall experience of course','Demographic','2014-02-24 06:10:10',5),(11,NULL,NULL,'conference feedback section 71','conference feedback section 71','Conference','2014-10-20 06:38:10',10),(12,NULL,NULL,'hoge','hgoe','Conference','2014-10-28 09:59:46',14),(13,NULL,NULL,'Session Feedback section conf 71','Session Feedback section conf 71','Conference','2014-10-31 02:50:33',11);
/*!40000 ALTER TABLE `feedback_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `map`
--

DROP TABLE IF EXISTS `map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `map` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Map_Directory` varchar(100) NOT NULL,
  `FilePath` varchar(20) NOT NULL,
  `Conference` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Map_Conference_fk` (`Conference`),
  CONSTRAINT `Map_Conference_fk` FOREIGN KEY (`Conference`) REFERENCES `conference` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map`
--

LOCK TABLES `map` WRITE;
/*!40000 ALTER TABLE `map` DISABLE KEYS */;
/*!40000 ALTER TABLE `map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `polling`
--

DROP TABLE IF EXISTS `polling`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `polling` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Polling_Question` varchar(150) NOT NULL,
  `Session` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Polling_Session_fk` (`Session`),
  CONSTRAINT `Polling_Session_fk` FOREIGN KEY (`Session`) REFERENCES `session` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `polling`
--

LOCK TABLES `polling` WRITE;
/*!40000 ALTER TABLE `polling` DISABLE KEYS */;
/*!40000 ALTER TABLE `polling` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `polling_option`
--

DROP TABLE IF EXISTS `polling_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `polling_option` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Option_Text` varchar(80) NOT NULL,
  `Polling` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Polling_Option_Polling_fk` (`Polling`),
  CONSTRAINT `Polling_Option_Polling_fk` FOREIGN KEY (`Polling`) REFERENCES `polling` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `polling_option`
--

LOCK TABLES `polling_option` WRITE;
/*!40000 ALTER TABLE `polling_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `polling_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `polling_response`
--

DROP TABLE IF EXISTS `polling_response`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `polling_response` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Medical_Profession` varchar(40) NOT NULL,
  `Polling_Option` smallint(5) unsigned NOT NULL,
  `Profile_Id` char(10) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Polling_Responses_Polling_Option_fk` (`Polling_Option`),
  CONSTRAINT `Polling_Responses_Polling_Option_fk` FOREIGN KEY (`Polling_Option`) REFERENCES `polling_option` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `polling_response`
--

LOCK TABLES `polling_response` WRITE;
/*!40000 ALTER TABLE `polling_response` DISABLE KEYS */;
/*!40000 ALTER TABLE `polling_response` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presenter`
--

DROP TABLE IF EXISTS `presenter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `presenter` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Title` varchar(20) NOT NULL,
  `First_Name` varchar(30) NOT NULL,
  `Last_Name` varchar(30) NOT NULL,
  `Organisation` varchar(150) NOT NULL,
  `Medical_Field` varchar(50) DEFAULT NULL,
  `Position` varchar(100) DEFAULT NULL,
  `Qualification` varchar(100) NOT NULL,
  `Short_Bio` varchar(250) NOT NULL,
  `Filepath` varchar(100) DEFAULT NULL,
  `Last_Updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presenter`
--

LOCK TABLES `presenter` WRITE;
/*!40000 ALTER TABLE `presenter` DISABLE KEYS */;
INSERT INTO `presenter` VALUES (2,'Professor','Ken','Boffard','Milpark Hospital','Surgery and Trauma','Professor of Surgery and Trauma Director','MBBS, FRACS','Ken Boffard is Professor of Surgery and Trauma Director at Milpark Hospital, Johannesburg, and until recently, Head of the Department of Surgery at Johannesburg Hospital and the University of the Witwatersrand. \r\n','No File Uploaded','2014-11-06 04:35:24'),(3,'Dr','Chiu Ming','Terk','Tan Tock Seng Hospital','General and Trauma Surgery','Head of Department of General Surgery, Director of Trauma','MBBS, FRACS','Dr Chiu is a Senior Consultant General and Trauma Surgeon, with special interests in trauma, critical care and head and neck surgery. He is currently the Head of General Surgery and the Director of Trauma in Tan Tock Seng Hospital.','No File Uploaded','2014-11-06 04:37:07'),(4,'Mr','Phillip','Antippa','RMH, Peter MacCallum','Cardiothoracic Surgery','Cardiothoracic Surgeon, RMH and Peter MacCallum','MBBS, FRACS','Phillip Antippa is a Cardiothoracic Surgeon at the Royal Melbourne Hospital and at Peter MacCallum Cancer Centre. He is the Director of the RMH Lung Cancer Service and is heavily involved in the Trauma Service.','No File Uploaded','2014-11-06 04:41:08'),(5,'Dr','Ian','Civil','Auckland CIty Hospital','Trauma Surgery','Director of Trauma Services','MBBS, FRACS','Ian has been Director of Trauma Services at Auckland City Hospital since 1992 and is now Associate Professor of Surgery in the Faculty of Medicine and Health Sciences. He has served on a number of international trauma organisations','No File Uploaded','2014-11-06 04:44:05'),(6,'Professor','Stephen','Deane','John Hunter Hospital','Trauma Surgery','Clinical Chair of Surgery','MBBS, FRACS','Stephen Deane is Professor of Surgery at the University of Newcastle, Clinical Chair of Surgery at John Hunter Hospital, & Program Director for Surgery for Hunter New England LHD. ','No File Uploaded','2014-11-06 04:48:29'),(7,'Dr ','Annette','Holian','Royal Darwin Hospital','Trauma Surgeon','Deputy Director of Trauma','MBBS, FRACS','Annette is an orthopaedic and trauma surgeon, & Deputy Director of Trauma at the National Critical Care and Trauma Response Centre, RDH. She holds the rank of Group Captain and is Clinical Director for Surgery & Perioperative Services, RAAF.','No File Uploaded','2014-11-06 04:50:56'),(8,'Dr ','Bhadu','Kavar','RMH, The Western, RCH','Neurosurgeory','Consultant Neurosurgeon','MBBS, FRACS','Bhadu Kavar is a consultant Neurosurgeon at The Royal Melbourne Hospital, The Western Hospital Footscray, and The Royal Childrenâ€™s Hospital. He has been an instructor for the DSTC Melbourne course since its commencement in 1998. ','No File Uploaded','2014-11-06 04:51:49'),(9,'Dr ','Brett','Knowles','RMH, St Vincent','General & Hepatobiliary Surgery','General and Hepatobiliary Surgeon','MBBS, FRACS','Brett Knowles is a General and Hepatobiliary Surgeon at Royal Melbourne, St Vincent\'s, and Peter MacCallum Hospitals.  He is part of the Royal Melbourne Trauma Service and underwent HPB and transplant training at Edinburgh and Basingstoke in the UK.','No File Uploaded','2014-11-06 04:53:07'),(10,'Dr','Kate','Martin','The Alfred','Trauma Surgery','General Surgeon (Trauma Surgery)','MBBS, FRACS','Kate is a General Surgeon, sub-specialising in Trauma Surgery. She is an instructor with the EMST and DSTC Faculties, and the Supervisor of General Surgical Training at the Alfred. Kate is also the secretary of ANZAST.','No File Uploaded','2014-11-06 04:53:52'),(11,'Dr ','Tim','Wagner','RMH, Epworth','Vascular and Endovascular Surgery','Surgeon','MBBS, FRACS','Tim Wagner is a Vascular and Endovascular Surgeon at The Royal Melbourne Hospital and The Epworth Hospital and Clinical Senior Lecturer in Vascular Surgery at the University of Melbourne and has special interest in Vascular Trauma. ','No File Uploaded','2014-11-06 04:54:39'),(12,'Professor','Daryl','Wall ','Princess Alexandra Hospital','Surgery','Professor of Surgery ','MBBS, FRACS','Daryl serves as an examiner for the RACS and the Australian Medical Council. Daryl is a member of 15 medical associations.  He has published over 150 papers, 3 books, 10 videos, and delivered over 100 invited lectures.  ','No File Uploaded','2014-11-06 04:57:02'),(13,'Dr','Martin','Wullschleger','Logan Hospital','General and Trauma Surgery','General and Trauma Surgeon','MBBS, FRACS','Martin is a Swiss and Australian qualified General and Trauma Surgeon, currently working as Consultant in the Acute Surgical Unit at Logan Hospital. Apart from his clinical involvement, he has an academic appointment with University of Queensland.','No File Uploaded','2014-11-06 22:55:04'),(14,'Dr ','Charles','Pilgrim','The Alfred','Upper GI and Trauma Surgery','Surgeon','MBBS, FRACS','Charles Pilgrim is an Upper GI and Trauma surgeon, with appointments to the Hepatopancreaticobiliary Service at The Alfred Hospital, the Trauma Surgery Service at The Alfred and in General and Emergency Surgery at Frankston Hospital','No File Uploaded','2014-11-07 00:54:10');
/*!40000 ALTER TABLE `presenter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_type`
--

DROP TABLE IF EXISTS `question_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `question_type` (
  `Question_Type` char(10) NOT NULL,
  `Type_Description` char(100) DEFAULT NULL,
  PRIMARY KEY (`Question_Type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_type`
--

LOCK TABLES `question_type` WRITE;
/*!40000 ALTER TABLE `question_type` DISABLE KEYS */;
INSERT INTO `question_type` VALUES ('Long','Expected to take over 10 minutes to explain'),('Multi','Far to complex to explain earthling'),('Short','Expected to take under 10 minutes to explain'),('Specific','An in depth question that requires previous experience in the field'),('VShort','Yes or No');
/*!40000 ALTER TABLE `question_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reponse_text`
--

DROP TABLE IF EXISTS `reponse_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reponse_text` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Question_Reponse` varchar(250) NOT NULL,
  `Feedback_Question` smallint(5) unsigned NOT NULL,
  `Feedback_Response` smallint(5) unsigned NOT NULL,
  `Profile_Id` char(10) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Reponse_Text_Feedback_Question_fk` (`Feedback_Question`),
  CONSTRAINT `Reponse_Text_Feedback_Question_fk` FOREIGN KEY (`Feedback_Question`) REFERENCES `feedback_question` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reponse_text`
--

LOCK TABLES `reponse_text` WRITE;
/*!40000 ALTER TABLE `reponse_text` DISABLE KEYS */;
INSERT INTO `reponse_text` VALUES (7,'QR00006',30,7,'DDDDDEACCB');
/*!40000 ALTER TABLE `reponse_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `response_option`
--

DROP TABLE IF EXISTS `response_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `response_option` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Feedback_Response` smallint(5) unsigned NOT NULL,
  `Feedback_Option` smallint(5) unsigned NOT NULL,
  `Profile_Id` char(10) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Response_Option_Feedback_Option_fk` (`Feedback_Option`),
  CONSTRAINT `Response_Option_Feedback_Option_fk` FOREIGN KEY (`Feedback_Option`) REFERENCES `feedback_option` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `response_option`
--

LOCK TABLES `response_option` WRITE;
/*!40000 ALTER TABLE `response_option` DISABLE KEYS */;
INSERT INTO `response_option` VALUES (12,6,116,'AABCCEEDAA'),(13,7,117,'DDDDDEACCB'),(14,8,118,'DDDDDEACCB');
/*!40000 ALTER TABLE `response_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Title` varchar(100) NOT NULL,
  `Description` varchar(400) DEFAULT NULL,
  `Start_Time` datetime NOT NULL,
  `End_Time` datetime NOT NULL,
  `Room_Location` varchar(20) NOT NULL,
  `Session_Chairperson` varchar(50) DEFAULT NULL,
  `Last_Updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Polling_Available` tinyint(1) NOT NULL,
  `Polling_Open` tinyint(1) NOT NULL,
  `Conference_Section` smallint(5) unsigned NOT NULL,
  `Feedback` smallint(5) unsigned DEFAULT NULL,
  `Feedback_Section` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Session_Conference_Section_fk` (`Conference_Section`),
  KEY `Session_Feedback_fk` (`Feedback`),
  KEY `Session_Feedback_Section_fk` (`Feedback_Section`),
  CONSTRAINT `Session_Conference_Section_fk` FOREIGN KEY (`Conference_Section`) REFERENCES `conference_section` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Session_Feedback_fk` FOREIGN KEY (`Feedback`) REFERENCES `feedback` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Session_Feedback_Section_fk` FOREIGN KEY (`Feedback_Section`) REFERENCES `feedback_section` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES (31,'9th Nov - Decision-making in Trauma: Case','Decision-making in Trauma: Case','2014-11-09 11:15:00','2014-11-09 11:30:00','Richmond Auditorium,','P. Antippa','2014-11-07 06:09:42',0,0,25,3,NULL),(32,'9th Nov - Surgical Decision-making in Trauma','Surgical Decision-making in Trauma','2014-11-09 11:30:00','2014-11-09 11:45:00','Richmond Auditorium,','P. Antippa','2014-11-07 06:09:49',0,0,25,3,NULL),(33,'9th Nov - Damage Control','Damage Control','2014-11-09 11:45:00','2014-11-09 12:00:00','Richmond Auditorium,','P. Antippa','2014-11-07 06:09:55',0,0,25,3,NULL),(34,'9th Nov - Case','Case','2014-11-09 12:05:00','2014-11-09 12:20:00','Richmond Auditorium,','P. Antippa','2014-11-07 06:10:04',0,0,25,3,NULL),(35,'9th Nov - Blunt Abdominal Trauma','Blunt Abdominal Trauma','2014-11-09 13:05:00','2014-11-09 13:20:00','Richmond Auditorium,','K. Martin','2014-11-07 06:10:16',0,0,25,3,NULL),(36,'9th Nov - Case','Case','2014-11-09 13:20:00','2014-11-09 13:35:00','Richmond Auditorium,','K. Martin','2014-11-07 06:10:25',0,0,25,3,NULL),(37,'9th Nov - Penetrating Abdominal Trauma','Penetrating Abdominal Trauma','2014-11-09 13:35:00','2014-11-09 13:50:00','Richmond Auditorium,','K. Martin','2014-11-07 06:10:35',0,0,25,3,NULL),(38,'9th Nov - Case','Case','2014-11-09 13:50:00','2014-11-09 14:05:00','Richmond Auditorium,','K. Martin','2014-11-07 06:10:47',0,0,25,3,NULL),(39,'9th Nov - Haemodynamically Unstable Pelvic Fracture','Haemodynamically Unstable Pelvic Fracture','2014-11-09 14:05:00','2014-11-09 14:20:00','Richmond Auditorium,','K. Martin','2014-11-07 06:10:55',0,0,25,3,NULL),(40,'9th Nov - Case','Case','2014-11-09 14:20:00','2014-11-09 14:35:00','Richmond Auditorium,','K. Martin','2014-11-07 06:11:08',0,0,25,3,NULL),(57,'Spleen','Groups 1-4 rotation','2014-11-09 15:00:00','2014-11-09 16:40:00','Room 3, Level 5LP','','2014-11-07 00:37:38',0,0,26,3,NULL),(58,'Trauma Lap','Groups 1-4 rotation','2014-11-09 15:00:00','2014-11-09 16:40:00','Room 5, Level 5LP','','2014-11-07 00:37:34',0,0,26,3,NULL),(59,'Pancreas','Groups 1-4 rotation','2014-11-09 15:00:00','2014-11-09 16:40:00','Room 6, Level 5LP','','2014-11-07 00:36:21',0,0,26,3,NULL),(60,'Liver','Groups 1-4 rotation','2014-11-09 15:00:00','2014-11-09 16:40:00','Room 2, Level 5LP','','2014-11-07 00:36:15',0,0,26,3,NULL),(61,'2.1.1','Penetrating Thoracic Trauma','2014-11-10 07:35:00','2014-11-10 07:50:00','Richmond Auditorium,','I. Civil','2014-11-07 00:47:32',0,0,25,3,NULL),(62,'2.1.2','Case','2014-11-10 07:50:00','2014-11-10 08:05:00','Richmond Auditorium,','I. Civil','2014-11-07 00:53:04',0,0,25,3,NULL),(63,'2.1.3','Blunt Thoracic Trauma','2014-11-10 08:05:00','2014-11-10 08:20:00','Richmond Auditorium,','I. Civil','2014-11-07 02:27:25',0,0,25,3,NULL),(64,'2.1.4','Case','2014-11-10 08:20:00','2014-11-10 08:35:00','Richmond Auditorium,','I. Civil','2014-11-07 01:16:20',0,0,25,3,NULL),(65,'2.1.5','Emergency Thoracotomy Overview','2014-11-10 08:35:00','2014-11-10 08:50:00','Richmond Auditorium,','I. Civil','2014-11-07 01:00:15',0,0,25,3,NULL),(66,'2.1.6','Case','2014-11-10 08:50:00','2014-11-10 09:05:00','Richmond Auditorium,','I. Civil','2014-11-07 01:01:03',0,0,25,3,NULL),(67,'2.2.1','Head Injury','2014-11-10 09:30:00','2014-11-10 09:45:00','Richmond Auditorium,','S. Deane','2014-11-07 01:03:14',0,0,25,3,NULL),(68,'2.2.2','Case','2014-11-10 09:45:00','2014-11-10 10:00:00','Richmond Auditorium,','S. Deane','2014-11-07 01:05:07',0,0,25,3,NULL),(69,'2.2.3','Penetrating Neck Injury','2014-11-10 10:00:00','2014-11-10 10:15:00','Richmond Auditorium,','S. Deane','2014-11-07 01:06:08',0,0,25,3,NULL),(70,'2.2.4','Case','2014-11-10 10:15:00','2014-11-10 10:30:00','Richmond Auditorium,','S. Deane','2014-11-07 01:07:11',0,0,25,3,NULL),(71,'2.2.5','Vascular Limb Injury','2014-11-10 10:30:00','2014-11-10 10:40:00','Richmond Auditorium,','S. Deane','2014-11-07 01:09:14',0,0,25,3,NULL),(72,'2.2.6','Case','2014-11-10 10:45:00','2014-11-10 11:00:00','Richmond Auditorium,','S. Deane','2014-11-07 01:09:51',0,0,25,3,NULL),(73,'Neck Exposure','Groups 1-4 rotation','2014-11-10 11:45:00','2014-11-10 13:25:00','Room 3, Level 5LP','','2014-11-07 01:17:12',0,0,26,3,NULL),(74,'Fasciotomy','Groups 1-4 rotation','2014-11-10 11:45:00','2014-11-10 13:25:00','Room 2, Level 5LP','','2014-11-07 01:17:01',0,0,26,3,NULL),(75,'Cardiac Repair','Groups 1-4 rotate','2014-11-10 11:40:00','2014-11-10 13:25:00','Room 6, Level 5LP','','2014-11-07 01:13:34',0,0,26,3,NULL),(76,'Craniotomy','Groups 1-4 rotate','2014-11-10 11:45:00','2014-11-10 13:25:00','Room 5, Level 5LP','','2014-11-07 01:16:48',0,0,26,3,NULL),(77,'Department of Anatomy','Practical Session, all groups ','2014-11-10 14:15:00','2014-11-10 17:15:00','Parkville Campus, Un','','2014-11-07 01:23:15',0,0,27,3,NULL),(78,'Real Time Trauma Surgery','All groups','2014-11-11 13:00:00','2014-11-11 16:00:00','St Vincent','','2014-11-07 01:23:08',0,0,27,3,NULL),(79,'eFAST & Cases','Groups A-F rotate','2014-11-11 08:30:00','2014-11-11 14:50:00','Clinical Skills Lab,','','2014-11-07 02:26:54',0,0,28,3,NULL),(80,'Simulation & Debrief','Groups A-F rotate','2014-11-11 08:30:00','2014-11-11 14:50:00','Rooms 5&6, Level 5LP','','2014-11-07 02:27:01',0,0,28,3,NULL),(81,'Problem Solving','Groups A-F rotate','2014-11-11 08:30:00','2014-11-11 14:50:00','Rooms 2&3, Level 5LP','','2014-11-07 02:27:10',0,0,28,3,NULL);
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session_equipment`
--

DROP TABLE IF EXISTS `session_equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session_equipment` (
  `Equipment` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`Equipment`),
  CONSTRAINT `Session_Equipment_Equipment_fk` FOREIGN KEY (`Equipment`) REFERENCES `equipment` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session_equipment`
--

LOCK TABLES `session_equipment` WRITE;
/*!40000 ALTER TABLE `session_equipment` DISABLE KEYS */;
INSERT INTO `session_equipment` VALUES (1),(2),(3),(4);
/*!40000 ALTER TABLE `session_equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session_presenter`
--

DROP TABLE IF EXISTS `session_presenter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session_presenter` (
  `Presenter` smallint(5) unsigned NOT NULL,
  `Session` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`Presenter`,`Session`),
  KEY `Session_Presenter_Session_fk` (`Session`),
  CONSTRAINT `Session_Presenter_Presenter_fk` FOREIGN KEY (`Presenter`) REFERENCES `presenter` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Session_Presenter_Session_fk` FOREIGN KEY (`Session`) REFERENCES `session` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session_presenter`
--

LOCK TABLES `session_presenter` WRITE;
/*!40000 ALTER TABLE `session_presenter` DISABLE KEYS */;
INSERT INTO `session_presenter` VALUES (5,31),(2,32),(6,33),(12,34),(3,35),(10,36),(9,37),(13,38),(7,39),(6,40),(2,57),(2,58),(2,59),(2,60),(4,61),(14,62),(13,63),(14,64),(4,65),(3,66),(8,67),(2,68),(11,69),(9,70),(5,71),(7,72),(2,73),(2,74),(2,75),(2,76),(2,77),(2,78),(2,79),(2,80),(2,81);
/*!40000 ALTER TABLE `session_presenter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session_question`
--

DROP TABLE IF EXISTS `session_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session_question` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Question` varchar(400) NOT NULL,
  `Accepted` tinyint(1) DEFAULT NULL,
  `Session` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Session_Question_Session_fk` (`Session`),
  CONSTRAINT `Session_Question_Session_fk` FOREIGN KEY (`Session`) REFERENCES `session` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session_question`
--

LOCK TABLES `session_question` WRITE;
/*!40000 ALTER TABLE `session_question` DISABLE KEYS */;
INSERT INTO `session_question` VALUES (29,'what\'s colours do you like?',0,31);
/*!40000 ALTER TABLE `session_question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sponsor`
--

DROP TABLE IF EXISTS `sponsor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sponsor` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(40) NOT NULL,
  `FilePath` varchar(100) DEFAULT NULL,
  `Short_Desc` varchar(250) NOT NULL,
  `URL` varchar(100) NOT NULL,
  `Last_Updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Session_Equipment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Sponsor_Session_Equipment_fk` (`Session_Equipment`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sponsor`
--

LOCK TABLES `sponsor` WRITE;
/*!40000 ALTER TABLE `sponsor` DISABLE KEYS */;
INSERT INTO `sponsor` VALUES (1,'Royal Australasian College of Surgeons','images/life.jpg','Formed in 1927 the Royal Australasian Collage of surgeons is a non-profit organisation.','http://www.surgeons.org','2014-10-27 22:17:50','PET');
/*!40000 ALTER TABLE `sponsor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `First_Name` char(25) NOT NULL,
  `Last_Name` char(30) NOT NULL,
  `User_name` varchar(30) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` char(32) NOT NULL,
  `Access_Level` enum('0','1') DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Geoffrey','Rose','Geoffreyrose','geoffrey.rose@epworth.org.au','fb6375b18ccb72b7c2cef0917526948b','1');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venue`
--

DROP TABLE IF EXISTS `venue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `venue` (
  `ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Name` char(30) NOT NULL,
  `Company` char(10) DEFAULT NULL,
  `Street` char(25) NOT NULL,
  `Suburb` char(10) NOT NULL,
  `Post_Code` smallint(4) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venue`
--

LOCK TABLES `venue` WRITE;
/*!40000 ALTER TABLE `venue` DISABLE KEYS */;
INSERT INTO `venue` VALUES (1,'Epworth Richmond','Epworth','89 Bridge Rd','Richmond',3005),(8,'University of Melbourne,','University','Cnr Grattan St and Royal','Parkville',3052),(9,'EMSU, St Vincent\'s Hospital','St Vincent','42 Fitzroy St','Fitzroy VI',3065);
/*!40000 ALTER TABLE `venue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'dstcapp'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-11-07 14:24:53

/** Automatically generated file. DO NOT MODIFY */
package au.edu.holmesglen.econference;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
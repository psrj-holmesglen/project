/**
 * Created by admin on 7/06/2014.
 */
eCon.MapRoot = "geo:0,0?q=";
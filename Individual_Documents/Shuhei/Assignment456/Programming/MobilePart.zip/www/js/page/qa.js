/**
 * @fileoverview Handles document load functions and global variables
 * @author Team Zelda
 */

$(function () {

  //$('#qa').on('click', '#btn-refresh', updateQAList);

  $('#qa')
  	.on('click', '#btn-refresh', updateQAList)
  	.change(function (evt) {

      var id = $(evt.target).val();
      if (id != "default") { // didn't select question

        $('#qa-submit').button('disable');
        //$('#form-sessid').val(id);
        $('form').show();
        $('#feed').show();
        $('#qa-question').val('');
        $('#qa-approved').collapsible('collapse');
        
        if ($(evt.target).prop('tagName') == 'SELECT') {
        	$('#form-sessid').val(id);
        }

        updateQAList();

      }

    });

});

function updateQAList() {
	
  var data = {
	Question: $('#form-question').val(),
	Answer: $('#form-profile').val(),
	Profile: $('#form-sessid').val()
  }

  $('#btn-refresh').addClass('ui-state-disabled');

  $.getJSON(eCon.WebDataRoot + "question-answer/" + $('#form-sessid').val()).
    done(function (data, status, xhr) {
      var list = $('#qa-list').empty();
      for (var i = data.length - 1; i >= 0; i--) {
        list.prepend($('<li>', {
          'class': 'wsn',
          append: data[i].Question
        }))
      }
      list.listview('refresh');
      $('#qa-count').text(data.length);
    }).
    always(function (a, status, c) {
      $('#btn-refresh').removeClass('ui-state-disabled');
    }).
    fail(ajaxLog);

}